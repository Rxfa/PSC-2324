#!/bin/sh

gcc max_value_test.c max_value.c -o max_value_test -g -Wall -pedantic