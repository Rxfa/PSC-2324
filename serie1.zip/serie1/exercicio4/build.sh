#!/bin/sh

gcc string_to_time.c string_to_time_test.c -o string_to_time_test -g -Wall -pedantic
