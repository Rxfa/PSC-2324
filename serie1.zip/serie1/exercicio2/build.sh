#!/bin/sh

gcc bits_test.c bits.c -o bits_test -g -Wall -pedantic
