#!/bin/sh

gcc string_split.c string_split_test.c -o string_split_test -g -Wall -pedantic
