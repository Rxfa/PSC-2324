#!/bin/sh

gcc csv_filter.c -o csv_filter -g -Wall
